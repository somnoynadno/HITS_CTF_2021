from flask import Flask, request, abort, render_template
from flask_cors import CORS, cross_origin

import os

app = Flask(__name__)
cors = CORS(app)


@app.route('/')
def index(methods=['GET']):
	return render_template('index.html')


@app.route('/api')
@cross_origin()
def api(methods=['GET']):
	return "Hello world"


@app.route('/api/public')
@cross_origin()
def api_public(methods=['GET']):
	# Everyone is allowed
	return "Hello, user"


@app.route('/api/private')
@cross_origin()
def api_private(methods=['GET']):
	# Need some secret key
	if request.args.get("key") != os.getenv("SECRET_KEY"):
		abort(403)

	return "Hello, admin"


if __name__ == "__main__":
	app.run(host="0.0.0.0", port=8000, debug=True)
